class CometDelivery: public Module {
public:
    CometDelivery(string name): Module(name) { init(); }

    double p, tau, F0, F1, max_conc, VOcean; //this

    void init(void) {
        this->links.push_back("Space -> Oceans2");
        this->links.push_back("Space -> OCrust2"); //this
        this->numOutputs = 1;
        this->init_fluxes(1);

        F0 = config->data["CometDelivery"]["F0"].as<double>();
        F1 = config->data["CometDelivery"]["F1"].as<double>();
        tau = config->data["CometDelivery"]["tau"].as<double>();
        max_conc = config->data["Erosion"]["max_conc"].as<double>(); //this
        VOcean = config->data["Erosion"]["VOcean"].as<double>(); //Volume of the Ocean in Liters   //this
    }

    void evolve(void) {
        int oc = s->reservoir_map["Oceans"];
        int cr = s->reservoir_map["OCrust"];   //this
        
        double max_mass = max_conc*VOcean*0.031;   //this

        double flux = F0 + (F1-F0)*exp(-s->time/tau);
        
        double outflux = 0; //this
        double oce_flux = flux; //this
        
        
        if(s->world[oc]->masses[p] + flux*s->timestep > max_mass && s->world[oc]->masses[p] <= max_mass) //all this
        {
        	outflux = (s->world[oc]->masses[p] + flux*s->timestep - max_mass)/s->timestep;
		
		oce_flux = flux - outflux;
        }
        
        if (s->world[oc]->masses[p] + flux*s->timestep > max_mass && s->world[oc]->masses[p] > max_mass) //all this
	{
		oce_flux = 0;
		outflux = flux;
	}

        s->world[oc]->fluxes[p] += oce_flux; // this is a net source, so no need to balance //this
        s->world[cr]->fluxes[p] += outflux; //this

	cout << "CometDelivery to ocean flux:: " << oce_flux << " to continental crust flux " << outflux << endl;
	
        if(DEBUG) cout << "CometDelivery::flux::" << flux << endl;

        vector<double> output = {flux};
        this->fluxes.push_back(output);
    }

    bool exec(string param) {
        if (param == "Init") {
            init();
            return true;
        }
        if (param == "Evolve") {
            evolve();
            return true;
        }
        return false;
    }
};
REGISTER_MODULE(CometDelivery)
