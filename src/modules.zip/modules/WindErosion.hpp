class WindErosion: public Module {
public:

    WindErosion(string name): Module(name) { init(); }

    double beta, satur, A0, M0, rho;
    bool uniform_growth;
    int p, co, oc, atm; //Phosphorus in continental crust, oceans and atmosphere
    
        void init(void) {
        this->links.push_back("CCrust2 -> Atmosphere0");
        this->links.push_back("CCrust2 -> Oceans2");
        //this->links.push_back("Oceans2 -> Atmosphere0");
        this->isBidirectional = true;
        this->numOutputs = 2;
        this->init_fluxes(2);

        beta = config->data["WindErosion"]["beta"].as<double>(); //Rate of continental wind erosion - kg.m⁻².yr⁻¹ (current day ~ 0.014 kg.m⁻².yr⁻¹)
        uniform_growth = config->data["WindErosion"]["uniform_growth"].as<bool>(); //Don't know what it is or does
        
        satur = config->data["WindErosion"]["satur"].as<double>(); // Saturation mass of P in the Atmosphere
        
        A0 = 1.48e14; // m2, today
        M0 = 2.28e22; // kg, today
        rho = 2700; // kg/m3

        p = s->element_map["p"];

        co = s->reservoir_map["CCrust"];
        oc = s->reservoir_map["Oceans"];
        atm = s->reservoir_map["Atmosphere"];
    }

    void evolve(void) {
        double relative_area;
        if (s->time < 1.5e9) { 
            relative_area = 0.02 + 0.64*s->time/1.5e9;
        } else {
            relative_area = 0.66 + 0.34*(s->time-1.5e9)/3e9;
        }
        if (uniform_growth) { relative_area = 0.02 + 0.98*s->time/4.5e9; } //Parametrization of Emerged land growth

        //double concentration = s->world[co]->masses[p]/(relative_area*M0); //Mass concentration of P in the continents
        double flux = beta*A0*relative_area; //wind erosion per year
	
	double outflux = 0;
	
	double atm_flux = flux; 
	
	if (s->world[atm]->masses[p] + flux*s->timestep > satur)
	{
		outflux = (s->world[atm]->masses[p] + flux*s->timestep - satur)/s->timestep; // If this flux leads to an oversaturated atmosphere, that outflux is authomatically redirected to the Oceans, in kg/yr
		
		atm_flux = flux - outflux; //the net flux into the atmosphere, in kg/yr
		
		//if(atm_flux < 0 && abs(atm_flux) > s->world[atm]->fluxes[p])
		//{
		//	atm_flux = - s->world[atm]->fluxes[p];
		//}
	
	}
	
        s->world[co]->fluxes[p] += -flux;
        s->world[atm]->fluxes[p] += atm_flux;
        s->world[oc]->fluxes[p] += outflux;

	cout << " wind erosion " << outflux << endl;


        if(DEBUG) {
            cout << "WindErosion::flux::" << flux << endl;
        }

        vector<double> output = {atm_flux, outflux};
        this->fluxes.push_back(output);
    }

    bool exec(string param) {
        if (param == "Init") {
            init();
            return true;
        }
        if (param == "Evolve") {
            evolve();
            return true;
        }
        return false;
    }
};
REGISTER_MODULE(WindErosion)
